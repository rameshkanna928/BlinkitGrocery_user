"use client";

import DynamicButton from "./components/buttons/DynamicButton";
import CampaignCard from "./components/cards/CampaignCard";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import { CampaignSliderSettings, JSONServerData } from "./utils/data";
import {
  Wrapper,
  Banner,
  BannerInfo,
  BannerText,
  BannerSubText,
  CategoryListContainer,
  CategoryListWrapper,
  LoaderFlexContainer,
  SCTitle,
  SCIMGBOX,
  SCIMGTAG,
} from "./assets/style";
import CategoryProductSlider from "./components/sliders/CategoryProductSlider";
import { useRouter } from "next/navigation";
import { AllCategory, BannerArrProps } from "./assets/style/interface";
import HomeProductSliders from "./components/sliders/HomeProductSliders";
import Link from "next/link";
import CampaignCardLoader from "./Loading UI/campaignCardLoader";
import CategoryListWrapperLoader from "./Loading UI/categoryListWrapperLoader";
import {
  fetchProductsByCategoryId,
  getAllCategoryWithTypes,
  getBanner,
} from "./service/api/data";
import { useEffect, useState, useContext } from "react";
import { gql, useLazyQuery, useQuery } from "@apollo/client";
import { getProductsByCategoryId } from "./service/query";
import { ICartItem, MyContext } from "../app/myContext";
import {
  setCartItems,
  setCategoryProducts,
  setUpdateCategoryProducts,
} from "./myContext/action";
import ProductCardLoader from "./Loading UI/productCardLoader";
import { updateQuantity } from "./helperFunctions";
import 'react-toastify/dist/ReactToastify.css';
import { USER_ID } from "./utils/variables";

export default function Home() {
  const router = useRouter();

  const { allBanners, bannerLoader } = getBanner();
  const bannerDatas: [BannerArrProps] = allBanners?.getAllBanner;
  // console.log("::::::", bannerDatas);
  // const { cartItems } = useContext(MyContext);
  const { allCategories, allCategoryLoader } = getAllCategoryWithTypes();
  // console.log("allCat", allCategories);
  const [sliderDatas, setSliderDatas] = useState([]);
  const staticCategoryId = [
    "65549be6b8cc555881cb43f3",
    "6555c9459ad354780c2e6c4c",
  ];
  const { cartItems, categoryProducts, dispatch } = useContext(MyContext);

  const [getProductsByCategory, { data, loading }] = useLazyQuery(
    getProductsByCategoryId
  );

  useEffect(() => {
    const cloneData = JSON.parse(JSON.stringify(sliderDatas));
    const intialLoad = async () => {
      staticCategoryId.map(async (value) => {
        const response = await getProductsByCategory({
          variables: { getCategoryWithProductTypesId: value, sliceCount: 10 },
        });
        cloneData.push(response?.data?.getCategoryWithProductTypes);
        setCategoryProducts(
          dispatch,response.data.getCategoryWithProductTypes 
        );
      });
      setSliderDatas(cloneData);
    };

    intialLoad();
  }, []);

  useEffect(() => {
    // setUpdateCategoryProducts(dispatch);
  }, [cartItems]);
  console.log("for slider products", categoryProducts);
  console.log("for slider products", cartItems);

  const cartQuery =gql`
  query GetAddToCartsByUserId($userId: ID!) {
    getAddToCartsByUserId(userId: $userId) {
      carts {
        id
        product {
          id
          name
          productCode
          shortDescription
          description {
            key
            value
          }
          variant {
            id
            size
            unit
            values
            price
            stock
          }
          tag
          image {
            id
            image
            imageList
          }
          rating
          dicountType
          dicountPercentage
          ratingCount
          isActive
          ProductType {
            id
            name
            image
            isActive
            defaultRoute
            productCategory {
              id
              name
              image
              isActive
              productTypes {
                id
                name
                image
                isActive
                defaultRoute
                productCategoryId
              }
              defaultRoute
            }
            productCategoryId
            products {
              id
              name
              productCode
              shortDescription
              tag
              rating
              dicountType
              dicountPercentage
              ratingCount
              isActive
              productTypeId
            }
          }
          productTypeId
        }
        productId
        quantity
        totalPrice
        user {
          id
          email
          phoneNo
          firstName
          lastName
          role
          profileImage
          isActive
          Address {
            id
            address
            apartment
            label
            userId
            pincode
          }
        }
        userId
        deviceToken
        isOrder
        selectedVariantId
        selectedVariant {
          id
          size
          unit
          values
          price
          stock
          ProductInventory {
            id
            productId
            branchId
            variantId
            availableStock
            minimumAvailableStock
          }
          AddToCart {
            id
            productId
            quantity
            totalPrice
            userId
            deviceToken
            isOrder
            selectedVariantId
          }
        }
      }
      subTotal
      count
    }
  }`
// const {data:check} =useQuery(cartQuery,{
//   variables:{
//     userId:USER_ID,
    
//   }
// })
// console.log("paginData",check);
  return (
    <Wrapper>
      <Banner>
        <BannerInfo>
          <BannerText>Don't miss out on tasty Grocery Deals</BannerText>
          <BannerSubText>
            Your Favourite grocery shop is now online
          </BannerSubText>
          <DynamicButton name="Shop Now" />
        </BannerInfo>
      </Banner>

      <CategoryProductSlider settings={CampaignSliderSettings}>
        {bannerLoader
          ? [0, 1, 2, 3, 4].map((_, id) => <CampaignCardLoader key={id} />)
          : bannerDatas &&
            bannerDatas.map((e) => <CampaignCard key={e.id} e={e} />)}
      </CategoryProductSlider>

      <CategoryListContainer>
        {allCategories?.getAllCategories?.map((data: AllCategory) => (
          // <Link href={`${data?.defaultRoute}`} key={data?.id}>
            <CategoryListWrapper $Loader={allCategoryLoader}>
              <div className="img-container">
                <img src={data?.image} />
              </div>
              {/* <SCIMGBOX>
                <SCIMGTAG src={data?.image} />
              </SCIMGBOX> */}
              <SCTitle $variant="H16CAT600">{data?.name}</SCTitle>
            </CategoryListWrapper>
          // </Link>
        ))}
        {allCategoryLoader && (
          <CategoryListWrapperLoader loaderState={allCategoryLoader} />
        )}
      </CategoryListContainer>
      {loading && (
        <LoaderFlexContainer>
          {Array(7)
            .fill(0)
            .map((_, i) => (
              <ProductCardLoader key={i} />
            ))}
        </LoaderFlexContainer>
      )}
      {categoryProducts?.map((data) => (
        <HomeProductSliders key={data?.id} data={data} />
      ))}
    </Wrapper>
  );
}
