"use client";
import Link from "next/link";
import {
  LinksTitleTag,
  SCLINK,
  SCTitle,
  StyledLink,
  TitleTag,
} from "../assets/style";
import { Grid } from "@mui/material";
import React from "react";
import { getAllCategoryWithTypes } from "../service/api/data";

function page() {
  const { allCategories, allCategoryLoader }: any = getAllCategoryWithTypes();
  const CategoryArr = allCategories?.getAllCategories;
  // console.log("for ",CategoryArr);

  return (
    <>
      <SCTitle $variant="H2460032 0 16">categories</SCTitle>
      {CategoryArr?.map((data: any) => {
        return (
          <React.Fragment key={data?.id}>
            <SCTitle $variant="H1870015 0">{data?.name}</SCTitle>
            <Grid rowGap={2} container>
              {data?.productTypes.map((value: any) => (
                <Grid key={value.id} item sm={6}>
                  <SCLINK $variant=""  href={value?.defaultRoute}>
                    {value?.name}
                  </SCLINK>
                </Grid>
              ))}
            </Grid>
          </React.Fragment>
        );
      })}
    </>
  );
}

export default page;
