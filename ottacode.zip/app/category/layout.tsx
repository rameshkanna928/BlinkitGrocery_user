"use client";
import React, { useContext } from "react";
import CategoryNavComponent from "../components/parts/CategoryNavComponent";
import { globalContext } from "../utils/states";
import { ChildrenProps } from "../assets/style/interface";

function Layout({ children }: ChildrenProps) {
  const { defaultRoutes }: any = useContext(globalContext);

  return (
    <>
      {defaultRoutes !== "category" ? (
        <>
          <CategoryNavComponent />
          {children}
        </>
      ) : (
        <> {children}</>
      )}
    </>
  );
}

export default Layout;
