import React, { useMemo, useReducer } from "react";
import Reducer from "./reducer";

export interface IAction {
  type: string;
  payload: any;
}

export interface ICartItem {
  id: string;
  quantity: number;
  categoryId: string;
  name: string;
  image: string;
  selectedvariant: {};
}
export interface SubCategoryProducts {
  name: string;
}
export interface products {
  name: string;
  products: [];
}
interface IInitialState {
  authStatus: boolean;
  productById:{},
  cartItems: ICartItem[];
  categoryProducts: any[];
  allProducts: any[];
  subCategoryProducts: products;
  productsByCategoryId: products;
  deliverDetails:{};
  clientSecret:string
  dispatch: IDispatch;
}

const initialState = ({
  authStatus: false,
  productById: {},
  cartItems: [],
  categoryProducts: [],
  allProducts: [],
  subCategoryProducts: {},
  productsByCategoryId: {},
  deliverDetails:null,
  clientSecret:null,
  dispatch: () => null,
} as unknown) as IInitialState;

export type IDispatch = React.Dispatch<IAction>;

export const MyContext = React.createContext(initialState);

export const MyContextProvider = ({
  children,
}: React.PropsWithChildren<any>) => {
  const [state, dispatch] = useReducer(Reducer, initialState);
  const value = useMemo(() => ({ ...state, dispatch }), [state]);

  return <MyContext.Provider value={value}>{children}</MyContext.Provider>;
};
