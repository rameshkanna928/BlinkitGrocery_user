import React, { useEffect, useState } from "react";
import { Text, SubText } from "../cart";
import { AddButton } from "@/app/components/buttons/Buttons";
import {
  ProductWrapper,
  ProductImageContainer,
  ProductImage,
  ProductInfoDetails,
} from "@/app/assets/style";

function CartProductCart({ e }: any) {

  return (
    <ProductWrapper>
      <ProductImageContainer>
        <ProductImage src={e?.image}></ProductImage>
      </ProductImageContainer>
      <ProductInfoDetails>
        <SubText padding="0 0 4px 0" style={{ width: "80%" }}>
          {e?.name}
        </SubText>
        <SubText padding="0 0 4px 0">
          {e?.selectedvariant?.values + e?.selectedvariant?.unit}
        </SubText>
        <Text style={{ fontSize: "12px" }}>${e?.selectedvariant?.price}</Text>
      </ProductInfoDetails>
      <AddButton variant={"cartCard"}  data={e} productId={e?.id} />
    </ProductWrapper>
  );
}

export default CartProductCart;
