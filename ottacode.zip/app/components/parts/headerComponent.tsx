"use client";

import {
  AccountHeader,
  AccountMenuWrapper,
  AccountPopupWrapper,
  Button,
  CustomLinkTag,
  CustomSpan,
  HeaderContainer,
  HeaderRightSec,
  HeaderRow,
  ImgTag,
  LocationSec,
  LocationWrapper,
  LogoSec,
  NavListItem,
  SearchBox,
  SearchSec,
  TitleTag,
} from "../../assets/style";
//Images
import logo from "../../assets/img/logo.png";
import { ExpandMore, Login, Search, ShoppingCart } from "@mui/icons-material";
import { useCallback, useContext, useEffect, useRef, useState } from "react";
import { Backdrop, Drawer, Modal } from "@mui/material";
import CartDrawer from "../cart";
import { IoMdContact } from "react-icons/io";
import { usePathname, useRouter } from "next/navigation";
import Link from "next/link";
import { globalContext } from "@/app/utils/states";
import { gql, useQuery } from "@apollo/client";
import { MyContext } from "../../myContext";
import { setAuthStatus, setCartItems } from "@/app/myContext/action";
import LoginPage from "../../auth/login";
import { IoMdArrowDropdown } from "react-icons/io";
import CustomPopper from "../elements/Popper";
import { CartTotalItems } from "@/app/helperFunctions";
import { USER_ID } from "@/app/utils/variables";

const HeaderComponent = ({ accountAnchor, openfunc, closeFunc }) => {
  const [open, setOpen] = useState(false);
  const [startSearch, setStartSearch] = useState(false);
  const [cartCount, setCartCount] = useState(0);
  const [currentCartItems, setCurrentCartItems] = useState([]);
  const handleOpen = useCallback(() => setOpen(true), []);
  const handleClose = useCallback(() => setOpen(false), []);
  const router = useRouter();
  const { defaultRoutes, search, setSearch } = useContext(globalContext);
  const { dispatch, cartItems, authStatus } = useContext(MyContext);
  const [billDetails, setBillDetails] = useState({
    subTotal: 0,
    deliveryFee: 0,
    totalAmount: 0,
  });
  // const { cartProducts } = fetchCartItems({
  //   userId:USER_ID,
  //   index:null,
  //   limit:null
  // });
  // const {data: cartProducts,refetch: cartRefetch,loading: cartLoader} = useQuery(getCartProducts,{
  //   variables: {
  //     userId:USER_ID,

  //   },
  // })

  const [showLogin, setShowLogin] = useState(false);
  // useEffect(() => {
  //   console.log("homeCart", cartProducts);

  //   if (cartProducts?.getAddToCartsByUserId?.carts?.length > 0) {
  //     cartProducts?.getAddToCartsByUserId?.carts?.map((data) => {
  //       console.log(data);

  //       setCartItems(dispatch, {
  //         id: data?.product?.id,
  //         quantity: data?.quantity,
  //         categoryId: data?.product?.ProductType?.productCategoryId,
  //         name: data?.product?.name,
  //         image: data?.product?.image?.image,
  //         selectedvariant: data.selectedVariant,
  //       });
  //     });
  //   }
  //   console.log("effect run", cartItems);
  // }, [cartProducts]);
  useEffect(() => {
    const cartItemsWithQuantity = cartItems?.filter(
      (data) => data.quantity !== 0
    );
    setCurrentCartItems(cartItemsWithQuantity);
    setCartCount(cartItemsWithQuantity.length);
    console.log("currentCartItems", cartItemsWithQuantity);
  }, [cartItems]);
  useEffect(() => {
    setBillDetails((prev) => ({
      ...prev,
      subTotal: currentCartItems?.reduce((acc, obj) => {
        return acc + obj?.quantity * obj?.selectedvariant?.price;
      }, 0),
      deliveryFee: currentCartItems?.deliveryFee ? cartItems?.deliveryFee : 0,
      totalAmount: prev?.subTotal + prev?.deliveryFee,
    }));
  }, [currentCartItems, billDetails.subTotal]);
  console.log(
    "bill",
    billDetails,
    currentCartItems,
    currentCartItems?.reduce((acc, obj) => {
      return acc + obj?.quantity * obj?.selectedvariant?.price;
    }, 0)
  );

  useEffect(() => {
    if (startSearch) {
      router.push(`/search/${search}`);
    }
  }, [search]);
  const path = usePathname();
  const pathArr = path.split("/");
  useEffect(() => {
    if (defaultRoutes?.length === 0) {
      setSearch("");
    }
  }, [defaultRoutes]);
  const authToken = localStorage.getItem("token");
  useEffect(() => {
    if (authToken) {
      setAuthStatus(dispatch, true);
    } else {
      setAuthStatus(dispatch, false);
    }
  }, [authToken]);

  return (
    <HeaderContainer>
      <HeaderRow>
        <LogoSec>
          {/* <Link href={"/"}>
              <ImgTag $imgfit="contain" src={logo} alt="logo" />
            </Link> */}
        </LogoSec>
        {!pathArr?.includes("search") && (
          <LocationWrapper>
            <LocationSec>
              <h4 className="title">Delivery in 17 minutes</h4>
              <div className="contentSec">
                <p className="content">
                  36P6+65H, 1st Main St, Y Block, Anna Nagar, Chennai, Tamil
                  Nadu 600040, India
                </p>
                <ExpandMore />
              </div>
            </LocationSec>
            <div className="login">
              <IoMdContact size={32} color={"black"} />
            </div>
          </LocationWrapper>
        )}

        <SearchSec>
          <SearchBox>
            <input
              onFocus={() => setStartSearch(true)}
              onBlur={() => setStartSearch(false)}
              onClick={() => {
                if (!search) router.push("/search");
              }}
              type="text"
              placeholder="Search for atta dal and more"
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
              }}
            />
            <Search className="searchIcon" />
          </SearchBox>
        </SearchSec>

        <HeaderRightSec>
          {!pathArr.includes("search") && (
            <>
              {!authStatus ? (
                <button
                  onClick={() => setShowLogin(true)}
                  className="buttonLink"
                >
                  <Login />
                  Login
                </button>
              ) : (
                <button className="buttonLink" onClick={openfunc}>
                  Account
                  <IoMdArrowDropdown />
                </button>
              )}

              <CustomPopper
                anchorEL={accountAnchor}
                closeFunc={closeFunc}
                variant="accountPopper"
              >
                <AccountPopupWrapper>
                  <AccountHeader>
                    <TitleTag>My Account</TitleTag>
                    <CustomSpan>54864564654</CustomSpan>
                  </AccountHeader>
                  <div>
                    <AccountMenuWrapper>
                      {/* <CustomLinkTag variant="link">My Orders</CustomLinkTag>
                      <CustomLinkTag variant="link">
                        Saved Address
                      </CustomLinkTag>

                      <CustomLinkTag variant="link">My Wallet</CustomLinkTag>
                      <CustomLinkTag variant="link">FAQ's</CustomLinkTag>

                      <CustomLinkTag
                        onClick={() => {
                          localStorage.removeItem("token");
                          closeFunc();
                          if (pathArr.includes("checkout")){
                            router.push("/")
                          }
                        }}
                        variant="link"
                      >
                        Log Out
                      </CustomLinkTag> */}
                    </AccountMenuWrapper>
                  </div>
                </AccountPopupWrapper>
              </CustomPopper>

              <LoginPage open={showLogin} onClose={() => setShowLogin(false)} />
            </>
          )}
          {!pathArr.includes("checkout") && (
            <Button $icon="left" onClick={handleOpen}>
              <ShoppingCart className="cart-icon" />
              <span>{CartTotalItems(currentCartItems)} item My Cart</span>
            </Button>
          )}

          <Drawer
            sx={{
              background: "1f1f1f",
              "& .css-1160xiw-MuiPaper-root-MuiDrawer-paper": {
                backgroundColor: "#f5f7fc",
              },
            }}
            anchor="right"
            open={open}
            onClose={handleClose}
          >
            <CartDrawer
              cartItems={currentCartItems}
              billDetails={billDetails}
              open={open}
              anchor="right"
              onClose={handleClose}
              openLogin={() => setShowLogin(true)}
            />
          </Drawer>
        </HeaderRightSec>
      </HeaderRow>
    </HeaderContainer>
  );
};

export default HeaderComponent;
