"use client";

import React, { useContext, useEffect, useState } from "react";
import { CustomAddButton } from "../../assets/style";
import { HiPlusSm } from "react-icons/hi";
import { HiMinusSm } from "react-icons/hi";
import { AiOutlineDelete } from "react-icons/ai";
import { ProductCardButtonProps } from "@/app/assets/style/interface";
import {
  addProducts,
  updateProducts,
  fetchProductsByCategoryId,
  getProductsByProductTypesId,
  searchProducts,
  fetchCartItems,
} from "@/app/service/api/data";
import { usePathname } from "next/navigation";
import { globalContext } from "@/app/utils/states";
import { setCartItems } from "@/app/myContext/action";
import { MyContext } from "../../myContext";
import { updateQuantity } from "@/app/helperFunctions";
import { USER_ID } from "@/app/utils/variables";

export const AddButton = ({
  data,
  variant,
  variantDetails,
  productId,
  ref,
  hideBackground,
}: any) => {
  const { addItems, addLoader } = addProducts();
  const { updateItems, deleteLoader } = updateProducts();
  const { dispatch } = useContext(MyContext);
  const [count, setCount] = useState(0);
  const [variantId, setVariantId] = useState<string>("");
  const [productPrice, setProductPrice] = useState(0);
  console.log("SSS", data);

  useEffect(() => {
    switch (variant) {
      case "productCard":
        if (data?.AddToCart?.length>0) {
          console.log("ADDDDDD", data?.AddToCart);

          setCount(data?.AddToCart?.[0]?.quantity);
        } else {
          setCount(0);
        }
        setVariantId(data?.id);
        setProductPrice(data?.price);

        break;
      case "cartCard":
        if (data?.selectedvariant) {
          setCount(data?.quantity);
          setVariantId(data?.selectedvariant?.id);
        }
        break;
      case "variantCard":
        console.log(data);
        if (variantDetails?.AddToCart) {
          setCount(variantDetails?.AddToCart?.quantity);
        } else {
          setCount(0);
        }
        setVariantId(variantDetails?.id);
        setProductPrice(variantDetails?.price);

        console.log("checkVar", variantDetails);

        break;
    }
    console.log(
      "count receive",
      data,
      "cccc",
      count,
      "56",
      data?.variant?.[0]?.id,
      variantId
    );
  }, [data, variantDetails]);

  const addToCart = async () => {
    const response = await addItems({
      variables: {
        input: {
          productId: productId,
          quantity: 1,
          userId: USER_ID,
          deviceToken: null,
          selectedVariantId: variantId,
          totalPrice: productPrice,
        },
      },
    });
    if (response) {
      const responseObj = response.data.addToCartProduct;
      console.log("addResponse", responseObj);
      updateQuantity(dispatch, responseObj);
    } else {
      alert("promise failed");
    }
  };
  const updateCart = async (quant: number) => {
    const response = await updateItems({
      variables: {
        input: {
          productId: productId,
          quantity: quant,
          userId: USER_ID,
          variantId: variantId,
        },
      },
    });
    if (response) {
      const responseObj = response.data.updateAddToCart;
      console.log("updateResponse", responseObj);
      updateQuantity(dispatch, responseObj);
    }
  };
  // useEffect(() => {
  // if (count !== productQuantity) {
  //   if (
  //     count === 1 &&
  //     (variantDetails?.AddToCart === null ||
  //       variantDetails?.AddToCart?.quantity === 0)
  //   ) {
  //     addToCart();
  //   } else if (
  //     //   (((variantDetails?.AddToCart||variantDetails?.selectedvariant) &&
  //     //     (count !== variantDetails?.AddToCart?.quantity||count !== productQuantity)) ||
  //     //     (productQuantity && count !== productQuantity)) &&
  //     //  ( variantDetails?.AddToCart !== null)
  //    ( count > productQuantity || count < productQuantity )
  //   ) {
  //     updateCart();
  //     console.log("calledUpdate");
  //   }
  // } else {
  //   return;
  // }

  //   if (variantDetails?.AddToCart === null || productQuantity === 0) {
  //     addToCart();
  //   } else if (variantDetails?.AddToCart !== null) {
  //     updateCart();
  //   }
  // }, [count]);
  return (
    <CustomAddButton
      ref={ref}
      $variant="productCard"
      disabled={addLoader || deleteLoader}
      $count={count}
      $disable={addLoader || deleteLoader}
      onClick={(e) => {
        e.stopPropagation();
      }}
      hideBackground={hideBackground}
    >
      {count === 0 ? (
        <span
          onClick={() => {
            addToCart();
          }}
        >
          ADD
        </span>
      ) : (
        <>
          {" "}
          <span
            onClick={() => {
              setCount((prev) => prev - 1);
              updateCart(-1);
              console.log(count);
            }}
          >
            {hideBackground ? (
              <HiMinusSm color={"black"} size={11} />
            ) : count === 1 ? (
              <AiOutlineDelete color={"white"} size={11} />
            ) : (
              <HiMinusSm color={"white"} size={11} />
            )}
          </span>{" "}
          {count}
          <span
            onClick={() => {
              setCount((prev) => prev + 1);
              updateCart(1);
              console.log(count, variantId);
            }}
          >
            <HiPlusSm color={hideBackground ? "black" : "white"} size={11} />
          </span>{" "}
        </>
      )}
    </CustomAddButton>
  );
};
