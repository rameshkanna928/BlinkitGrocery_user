"use client";
import { ProductContainer, ProductLeftSection } from "@/app/assets/style";
import ProductDetails from "@/app/[prname]/prid/[prid]/ProductDetails";
import ProductRight from "@/app/[prname]/prid/[prid]/ProductRight";
import { getProduct } from "@/app/service/query";
import { useLazyQuery, useQuery } from "@apollo/client";
import ReactImageMagnify from "react-image-magnify";
import React, { useContext, useEffect, useState } from "react";
import { MyContext } from "@/app/myContext";
import { setIndividualProduct, setUpdateIndividualProduct } from "@/app/myContext/action";

function page({ params }: { params: { prname: string; prid: string } }) {
  
  const { data,refetch } = useQuery(getProduct, {
    variables: {
      getProductId: params?.prid,
    },
    onCompleted: (data) => {
      setIndividualProduct(dispatch, {
        category: {
          name: data?.getProduct?.ProductType?.name,
          id: data?.getProduct?.ProductType?.productCategoryId,
        },
        subCategory: { id: data?.getProduct?.ProductType?.id },
        product:{
          id:data?.getProduct?.id,
          name:data?.getProduct?.name,
          image:data?.getProduct?.image?.image,
          discount:data?.getProduct?.dicountPercentage,
         variant:data?.getProduct?.variant
        }
      });
      console.log("globalProductByID", productById, "zdfd", data);
    }
  });
  let images = data?.getProduct?.ProductType?.image;
  const { productById, dispatch,cartItems } = useContext(MyContext);

  const [image, setImage] = useState("");
  const [variantDetails, setVariantDetails] = useState({});
  
  useEffect(() => {
    console.log("productDta", data);
    if (images) {
      setImage(images);
    }
  }, [images]);
  console.log("globalProductByID",productById);
  useEffect(()=>{
refetch();
  },[params?.prid])
  useEffect(()=>{
  setUpdateIndividualProduct(dispatch)
  
  },[cartItems])
  console.log("onPPP",productById );
  useEffect(() => {
    if (productById?.product?.variant?.length > 1) {
      let defaultVariant = productById?.product?.variant?.find(
        (data) => data?.id === variantDetails?.id
      );
      if (defaultVariant) {
        console.log("sdddddddd", defaultVariant);

        setVariantDetails(defaultVariant);
      } else {
        console.log("ssddddddddd", data?.product?.variant[0]);

        setVariantDetails(productById?.product?.variant[0]);
      }
    }
  },[productById]);
  console.log("checkVar", productById,variantDetails);
const selectVariantFunc =(variant)=>{
   setVariantDetails(variant)
}
  return (
    <div>
      <ProductContainer>
        <ProductLeftSection>
          <div className="productViewer">
            <div className="perimeter">
              <div className="image">
                <ReactImageMagnify
                  enlargedImageContainerStyle={{
                    left: "130%",
                    top: "8%",
                    zIndex: 20,
                    borderColor: "#f2f2f2",
                  }}
                  {...{
                    smallImage: {
                      src: image,
                      width: 480,
                      height: 480,
                      isFluidWidth: false,
                    },
                    largeImage: {
                      src: image,
                      width: 1426,
                      height: 2000,
                    },
                    enlargedImageContainerDimensions: {
                      width: "180%",
                      height: "180%",
                    },

                    isHintEnabled: true,
                  }}
                />
              </div>
            </div>
            {/* <SimpleSlider
              imagesArr={sliderArr}
              setImage={setImage}
              image={image}
            /> */}
          </div>
          <ProductDetails  />
        </ProductLeftSection>
        <ProductRight data={productById} variantDetails={variantDetails} selectVariant={(variant)=>selectVariantFunc(variant)} />
      </ProductContainer>
    </div>
  );
}

export default page;
