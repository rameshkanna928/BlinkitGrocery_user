"use client";
import React, { useContext, useEffect, useState } from "react";
import {
  BorderLessInput,
  CheckoutBtn,
  FlexBox,
  SCContainer,
  SCIMGBOX,
  SCIMGTAG,
  SCScrollBox,
  SCTitle,
} from "../assets/style";
import {
  Paper,
  TableContainer,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  TablePagination,
} from "@mui/material";
import page from "../page";
import { MyContext } from "../myContext";
import { AddButton } from "../components/buttons/Buttons";
import { IoMdClose } from "react-icons/io";
import {
  useStripe,
  useElements,
  PaymentElement,
} from "@stripe/react-stripe-js";
import { PaymentIntentResult, loadStripe } from "@stripe/stripe-js";
import { useMutation } from "@apollo/client";
import { getClientSecret } from "../service/mutation";
import { Elements } from "@stripe/react-stripe-js";
import CartLoader from "../Loading UI/cartLoader";
import { CartTotalAmount } from "../helperFunctions";

const Renderchild = () => {
  const stripe = useStripe();

  const elements = useElements();

  const [errorMessage, setErrorMessage] = useState(null);

  const handleSubmit = async (event) => {
    // We don't want to let default form submission happen here,
    // which would refresh the page.
    event.preventDefault();
    console.log("called");

    if (!stripe || !elements) {
      // Stripe.js hasn't yet loaded.
      // Make sure to disable form submission until Stripe.js has loaded.
      return;
    } else {
      const callFunc = async () => {
        await stripe
          .confirmPayment({
            elements,
            //`Elements` instance that was used to create the Payment Element
            // clientSecret: clientSecrett,
            confirmParams: {
              return_url: "https://localhost:3000/orders",
            },
            redirect: "if_required",
          })
          .then(async function (result: PaymentIntentResult) {
            console.log("resultresultresult", result);

            if (result?.paymentIntent?.status === "succeeded") {
              try {
                alert("payment completed!");
                console.log("Order placed:", data);

                // Display a success message or perform any other necessary actions
              } catch (error) {
                console.error("Error placing order:", error);

                // toast.error("Failed to place order");
              }
            } else if (result.error) {
              // Inform the customer that there was an error.
              setErrorMessage(result?.error.message);
            }
          })
          .catch((err) => {
            console.log(err);
          });
      };
      callFunc();
    }
  };
  return (
    <form onSubmit={handleSubmit}>
      <SCContainer $variant="p-15-0">
        <SCTitle $variant="h13Unit">Payment Method</SCTitle>
      </SCContainer>
      <PaymentElement />

      <CheckoutBtn>Check Out</CheckoutBtn>
    </form>
  );
};
function Page() {
  const { cartItems } = useContext(MyContext);
  const [checkoutLoader, setCheckOutLoader] = useState(false);
  const [secretKey, setSecretKey] = useState(null);
  const [getClient, { data }] = useMutation(getClientSecret);
  const rowsArr = [3, 6, 10];
  const [rowsPerPage, setRowsPerPage] = useState(3);
  const [pageNumber, setPageNumber] = useState(0);
  const columnData = cartItems?.slice(
    pageNumber * rowsPerPage - rowsPerPage,
    pageNumber * rowsPerPage
  );

  useEffect(() => {
    async function fetchClientDetails() {
      try {
        const { data } = await getClient({
          variables: {
            input: {
              amount: cartItems?.reduce((acc, obj) => {
                return acc + obj?.quantity * obj?.selectedvariant?.price;
              }, 10),
              currency: "inr",
              email: "user@gmail.com",
              name: "user",
            },
          },
        });
        setSecretKey(data?.cardPayment?.clientSecret);
      } catch (err) {
        console.log(err);
      }
    }
    fetchClientDetails();
  }, []);
  console.log(data, "??", secretKey);

  //stripe

  const stripePromise = loadStripe(
    "pk_test_51NjzQvSAjtfPsOjiVt5KLqh9Uc7Xzr6sF2ubVINDNoBqUPMdNJk1A33Pb0NrVm81AYUSQHVYdVXTQ2EEqRJBuhDu00Efneyegv"
  );
  const options = {
    // passing the client secret obtained in step 3
    clientSecret: secretKey,
    // Fully customizable with appearance API.
    appearance: {
      /*...*/
    },
  };
  const handleChangeRowsPerPage = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setRowsPerPage(event.target.value);
  };

  const handleChangePage = (event: unknown, newPage: number) => {
    setPageNumber(newPage);
  };
  return (
    <>
      {secretKey && (
        <FlexBox $disable={null} $variant="betweenwhite">
          <SCContainer $variant="w-3/5">
            <SCTitle $variant="H24700">Shopping Cart.</SCTitle>
            <Paper
              sx={{
                width: "100%",
                overflow: "hidden",
                boxShadow: "none",
                position: "relative",
                zIndex: 0,
              }}
            >
              <SCScrollBox $boxHeight="90vh">
                <Table stickyHeader aria-label="sticky table">
                  <TableHead>
                    <TableRow>
                      {["Product", "Size", "Quantity", "Total Price"].map(
                        (column) => (
                          <TableCell
                            sx={{
                              padding: 0,
                              paddingTop: "10px",
                              paddingBottom: "10px",
                            }}
                            //   key={column.id}
                            //   align={column.align}
                            //   style={{ minWidth: column.minWidth }}
                          >
                            <SCTitle $variant="H14600">{column}</SCTitle>
                          </TableCell>
                        )
                      )}
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {cartItems
                      .slice(
                        (pageNumber + 1) * rowsPerPage - rowsPerPage,
                        (pageNumber + 1) * rowsPerPage
                      )
                      .map((rowData) => {
                        return (
                          <TableRow
                            hover
                            role="checkbox"
                            tabIndex={-1}
                            key={rowData?.id}
                            sx={{
                              ":hover": {
                                backgroundColor: "transparent !important",
                              },
                            }}
                          >
                            <TableCell
                              sx={{
                                padding: 0,
                                paddingTop: "10px",
                                paddingBottom: "10px",
                              }}
                            >
                              <FlexBox $variant="align-cstart" $disable={null}>
                                <SCIMGBOX $variant="w-35h-35">
                                  <SCIMGTAG src={rowData?.image} />
                                </SCIMGBOX>

                                <SCTitle $variant="H13600">
                                  {rowData?.name}
                                </SCTitle>
                              </FlexBox>
                            </TableCell>
                            <TableCell
                              sx={{
                                padding: 0,
                                paddingTop: "10px",
                                paddingBottom: "10px",
                              }}
                            >
                              <SCTitle $variant="H12UNIT">
                                {rowData?.selectedvariant?.values +
                                  " " +
                                  rowData?.selectedvariant?.unit}
                              </SCTitle>
                            </TableCell>
                            <TableCell>{rowData?.quantity}</TableCell>
                            <TableCell>
                              <SCTitle $variant="H16UNIT600">
                                ₹
                                {rowData?.quantity *
                                  rowData?.selectedvariant.price}
                              </SCTitle>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                  </TableBody>
                </Table>
              </SCScrollBox>
              <TablePagination
                rowsPerPageOptions={rowsArr}
                component="div"
                count={cartItems.length}
                rowsPerPage={rowsPerPage}
                page={pageNumber}
                onPageChange={handleChangePage}
                onRowsPerPageChange={handleChangeRowsPerPage}
              />
            </Paper>
            <FlexBox $variant="end" $disable={null}>
              <SCContainer $variant="w-3/10">
                <FlexBox $variant="between" $disable={null}>
                  <SCTitle $variant="H16UNIT600">Subtotal:</SCTitle>
                  <SCTitle $variant="H16UNIT600">${CartTotalAmount(cartItems)}
</SCTitle>
                </FlexBox>
              </SCContainer>
            </FlexBox>
          </SCContainer>
          <SCContainer $variant="w-3/10p15bg-gray">
            <SCTitle $variant="H24600">Payment Info.</SCTitle>
            {secretKey && (
              <Elements stripe={stripePromise} options={options}>
                <Renderchild setCheckOutLoader={setCheckOutLoader} />
              </Elements>
            )}
          </SCContainer>
        </FlexBox>
      )}
    </>
  );
}

export default Page;
