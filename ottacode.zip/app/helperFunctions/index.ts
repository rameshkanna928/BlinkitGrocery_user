import { useContext } from "react";
import { setCartItems } from "../myContext/action";
import { IDispatch, MyContext } from "../myContext";

export const updateQuantity = (
  dispatch: IDispatch,
  responseObj: {
    productId: string;
    quantity: number;
    product: {
      name: string;
      ProductType: { productCategoryId: string };
      image: { image: string };
    };
    selectedVariant: {};
  }
) => {
  setCartItems(dispatch, {
    id: responseObj.productId,
    quantity: responseObj.quantity,
    categoryId: responseObj.product.ProductType.productCategoryId,
    name: responseObj.product.name,
    image: responseObj.product.image.image,
    selectedvariant: responseObj.selectedVariant,
  });
};

export const updateProductsArr = (
  productsArr: {
    id: string;
    productsArr: { id: string; AddToCart: { quantity: number } }[];
  }[],
  cart: { id: string; quantity: number; selectedvariant: { id: string } }[]
) => {
  console.log("check incoming", productsArr, cart);

  const updateProducts = productsArr?.map((prod) => {
    const correspondingCartItem = cart.filter(
      (cartItem) => cartItem.id === prod.id
    );

    if (correspondingCartItem) {
      const updatedVariants = prod.variant.map((variantItem) => {
        const getSelectedVariant = correspondingCartItem.find(
          (variant) => variant.selectedvariant.id === variantItem?.id
        );
        if (getSelectedVariant) {
          if (getSelectedVariant.quantity > 0) {
            return {
              ...variantItem,
              AddToCart: {
                ...variantItem.AddToCart,
                quantity: getSelectedVariant.quantity,
              },
            };
          } else {
            return {
              ...variantItem,
              AddToCart: null,
            };
          }
        } else {
          return variantItem;
        }
      });

      return {
        ...prod,
        variant: updatedVariants,
      };
    } else {
      return prod;
    }
  });

  console.log("vf", updateProducts);
  return updateProducts;
};

export const updateProductObj = (productsObj, cartItems) => {
  console.log("12", productsObj, cartItems);
  const selectedProduct = cartItems?.filter(
    (value) => value?.id === productsObj?.product?.id
  );
  console.log("12", selectedProduct);

  if (selectedProduct) {
    const updateVariant = productsObj?.product?.variant?.map((data) => {
      const selectedVariant = cartItems.find(
        (value) => value?.selectedvariant?.id === data?.id
      );
      console.log("12id", selectedVariant);
      if (selectedVariant) {
        if (selectedVariant?.quantity > 0) {
          return {
            ...data,
            AddToCart: data.AddToCart.map((data, index) => {
              if (index === 0) {
                return { ...data, kjdsbkjgsbfkjg: selectedVariant?.quantity };
              } else {
                return data;
              }
            }),
            // {
            //   ...data?.AddToCart,
            //   quantity: selectedVariant?.quantity,
            // },
          };
        } else {
          return {
            ...data,
            AddToCart: null,
          };
        }
      } else {
        return data;
      }
    });
    console.log("12id", updateVariant);

    return {
      ...productsObj,
      product: { ...productsObj.product, variant: updateVariant },
    };
  } else {
    productsObj;
  }
};

export const CartTotalItems = (items) => {
  return items?.reduce((acc, obj) => {
    return acc + obj?.quantity;
  }, 0);
};
export const CartTotalAmount = (items) => {
  return items?.reduce((acc, obj) => {
    return acc +  (obj?.quantity * obj?.selectedvariant?.price);
  }, 0);
};